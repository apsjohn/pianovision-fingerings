# This is the final, correct piano_fingering.py that mimics the official workflow.

from __future__ import annotations
from typing import List, Tuple

# We import the exact same components used by the official core.py
from .scorereader import reader as original_reader
from .hand import Hand

def compute_all(score: stream.Score, size: str = "M"):
    """
    This is a thin wrapper that calls the pianoplayer library's components
    in the same sequence as the official command-line interface.

    It processes the entire score twice, once for each hand.
    """
    
    # --- Right Hand Pass ---
    # Call the original reader on the FULL score, asking for the right-hand part (beam 0).
    rh_noteseq = original_reader(score, beam=0)
    
    # Create the Hand object with the full right-hand note sequence.
    rh_hand = Hand(rh_noteseq, side="right", size=size)
    
    # Run the fingering generation.
    if rh_noteseq: # Only run if notes were found
        rh_hand.generate()


    # --- Left Hand Pass ---
    # Call the original reader on the FULL score, asking for the left-hand part (beam 1).
    lh_noteseq = original_reader(score, beam=1)

    # Create the Hand object with the full left-hand note sequence.
    lh_hand = Hand(lh_noteseq, side="left", size=size)
    
    # Run the fingering generation.
    if lh_noteseq: # Only run if notes were found
        lh_hand.generate()

    # Return the results. The .noteseq attribute of the Hand object
    # now contains the INote objects with the .fingering attribute populated.
    return lh_hand.noteseq, rh_hand.noteseq
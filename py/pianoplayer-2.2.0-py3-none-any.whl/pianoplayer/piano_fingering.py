# This is the final, definitive version of piano_fingering.py

from __future__ import annotations
from typing import List, Tuple
from music21 import stream, chord

# We need these specific components from the library
from .scorereader import INote
from .utils import keypos
from .hand import Hand

def _convert_stream_to_inotes(m21_stream: stream.Stream, tpqn: int) -> List[INote]:
    """
    A robust function to convert a music21 stream into a list of INote objects,
    using the provided TPQN to correctly calculate ticks.
    """
    noteseq = []
    for n in m21_stream.flat.notesAndRests:
        if n.isRest or n.duration.quarterLength == 0:
            continue
        if hasattr(n, 'tie') and n.tie and (n.tie.type == 'continue' or n.tie.type == 'stop'):
            continue

        notes_to_process = n.notes if n.isChord else [n]
        for cn in notes_to_process:
            an = INote()
            an.pitch = cn.pitch.midi
            an.ticks = int(n.offset * tpqn)
            an.time = float(n.offset)
            an.duration = float(n.duration.quarterLength)
            an.x = keypos(cn)
            an.isBlack = cn.pitch.pitchClass in [1, 3, 6, 8, 10]
            an.note21 = cn # Store the original object
            noteseq.append(an)
            
    return noteseq

def _run_fingering_for_one_hand(m21_stream: stream.Stream, side: str, size: str, tpqn: int):
    """Processes a single hand, with safety checks."""
    inotes = _convert_stream_to_inotes(m21_stream, tpqn)

    if len(inotes) < 9:
        order = range(1, 6)
        for i, n in enumerate(inotes):
            n.fingering = order[i % 5]
        return inotes

    hand = Hand(inotes, side=side, size=size)
    hand.generate()
    return inotes

def compute_all(score: stream.Score, size: str = "M"):
    """
    Main entry point. Splits the score and then calls the fingering
    process for each hand.
    """
    # --- THIS IS THE CORRECTED LINE ---
    # Get the TPQN from the score's associated MIDI data.
    # Defaults to 480 if it's not available (e.g., for MusicXML).
    tpqn = 480
    if hasattr(score, 'midiFile') and score.midiFile:
        tpqn = score.midiFile.ticksPerQuarterNote

    if len(score.parts) >= 2:
        rh_stream, lh_stream = score.parts[0], score.parts[1]
    else:
        # Using the robust dynamic split we designed earlier
        lh_stream = stream.Stream()
        rh_stream = stream.Stream()
        recent: List[int] = []
        cur = 60
        WINDOW = 16
        MIN_GAP = 5
        
        def _iter_notes(s: stream.Stream):
            for el in s.recurse().notes:
                if isinstance(el, chord.Chord): yield from el.notes
                else: yield el

        for n in _iter_notes(score):
            p = n.pitch.midi
            recent.append(p)
            if len(recent) > WINDOW: recent.pop(0)
            if len(recent) == WINDOW:
                # Need to import statistics for this to work
                import statistics
                cur = statistics.median(recent)
            target = lh_stream if p <= cur - MIN_GAP else rh_stream if p >= cur + MIN_GAP else (lh_stream if p < cur else rh_stream)
            target.insert(n.offset, n)

    left_hand_inotes = _run_fingering_for_one_hand(lh_stream, "left", size, tpqn)
    right_hand_inotes = _run_fingering_for_one_hand(rh_stream, "right", size, tpqn)

    return left_hand_inotes, right_hand_inotes